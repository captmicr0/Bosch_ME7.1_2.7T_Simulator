#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include "pico/stdlib.h"
#include "hardware/clocks.h"
#include "hardware/dma.h"
#include "hardware/pio.h"
#include "hardware/structs/dma.h"
#include "hardware/spi.h"
#include <math.h>
#include "engine_profile.h"
#include "pico/multicore.h"
#include "capture.pio.h"
#include "status_led.pio.h"
#include "pico/stdio_usb.h"
#include "wave_dma.h"

// Requested wiring: cam GP2/G40 and GP3/G163; DAC SPI0 CS=5 SCK=6 MOSI=7 LDAC=4.
// Coil 1..6 GP10..GP15; injector 1..5 GP21..GP17; INJ6 GP26.
// WS2812 onboard RGB GP16 (not a capture input).
// GP22 is a local 720-degree marker, not an ECU connection.
#define G40_GPIO 2u
#define G163_GPIO 3u
#define DAC_LDAC_GPIO 4u
#define DAC_CS_GPIO 5u
#define DAC_SCK_GPIO 6u
#define DAC_MOSI_GPIO 7u
#define MON_GPIO 10u
#define MARKER_GPIO 22u
#define STATUS_LED_GPIO 16u
#define STATUS_LED_SM 2u
#define DAC_VREF_MV 2048u
// For 2.048 V reference, 1x gain: midpoint 1.024 V and +/- 0.9 V on each leg.
// Differential peak is ~1.8 V, before output resistors / shunt loading.
#define DAC_CENTER_CODE 2048u
#define DAC_PEAK_CODE 1800u
#define DAC_SAMPLES_PER_TOOTH 8u
#define CHANNELS 12u
#define SAMPLE_HZ 125000u
#define RING_BITS 15u
#define RING_BYTES (1u << RING_BITS)
#define RING_SAMPLES (RING_BYTES / 4u)
#define RING_MASK (RING_SAMPLES - 1u)
#define REPORT_MS 250u
#define EVENT_QUEUE 512u
#define MAX_RPM 12000u
#define MIN_RPM 100u

static uint32_t sample_ring[RING_SAMPLES] __attribute__((aligned(RING_BYTES)));
static PIO cap_pio = pio1;
static const uint cap_sm = 0;
static int dma_ch;
static volatile uint32_t rpm = 0;
static volatile uint32_t requested_rpm = 0;
static volatile uint32_t shape_version = 0;
static engine_shape_t shape = { {120, 60, false}, {480, 60, false}, {60, 2, false} };
// Default cam offsets are for waveform bring-up only, NOT APB-verified.
static volatile uint32_t waveform_cycle = 0; // 720-degree cycles observed by capture
static uint64_t sample_read = 0;
static uint64_t drop_samples = 0;
static uint16_t previous = 0;
static bool have_phase = false;
static uint64_t last_marker = 0;
static uint32_t marker_period_samples = 0;
static uint32_t phase_rpm = 0;
static uint32_t phase_epoch = 0;
static uint32_t observed_shape_version = 0;
static int16_t cyl1_tdc_deg = 0; // PROVISIONAL: calibrate with known APB TDC
static uint16_t start_angle[CHANNELS];
static int16_t start_relative[CHANNELS];
static uint8_t start_phase_valid[CHANNELS];
static bool previous_valid = false;
static bool previous_marker = false;
static bool stream = false;
static uint32_t rising_count[CHANNELS] = {0};
static uint32_t falling_count[CHANNELS] = {0};
static uint32_t pulse_us[CHANNELS] = {0};
static uint64_t start_sample[CHANNELS] = {0};
static bool active[CHANNELS] = {0};
static uint16_t polarity_mask = 0x0fc0; // injector MOSFET output active HIGH; ignition MOSFET outputs active LOW
static uint64_t event_drops = 0;
static volatile uint32_t last_ecu_activity_ms = 0;
static uint64_t status_last_sample_drops = 0;
static uint64_t status_last_event_drops = 0;
static uint32_t status_last_wave_underruns = 0;
static bool error_latched = false;
static uint32_t last_led_update_ms = 0;
static uint32_t last_led_value = UINT32_MAX;

// Standard one-wire WS2812, GRB order. Uses PIO0 SM2, leaving SM0/SM1
// exclusively owned by crank/cam waveform generation. Never blocks capture.
static void status_led_init(void) {
    uint offset = pio_add_program(pio0, &status_led_program);
    status_led_program_init(pio0, STATUS_LED_SM, offset, STATUS_LED_GPIO);
}
static void status_led_update(void) {
    uint32_t now = to_ms_since_boot(get_absolute_time());
    if ((uint32_t)(now - last_led_update_ms) < 25u) return;
    last_led_update_ms = now;
    if (drop_samples > status_last_sample_drops ||
        event_drops > status_last_event_drops ||
        wave_dma_underruns > status_last_wave_underruns) error_latched = true;
    status_last_sample_drops = drop_samples;
    status_last_event_drops = event_drops;
    status_last_wave_underruns = wave_dma_underruns;

    uint8_t red=0, green=0, blue=0;
    if (error_latched) { // Latching faults avoids hiding a brief capture loss.
        if ((now / 250u) & 1u) red = 36;
    } else if (rpm == 0u) {
        // CDC connected means a host has opened the USB serial interface.
        // When disconnected, pulse blue slowly instead of staying solid.
        if (stdio_usb_connected()) blue = 20;
        else blue = (uint8_t)(3u + (now / 40u % 50u < 25u ?
            (now / 40u % 50u) : 49u - (now / 40u % 50u)) / 2u);
    } else if ((uint32_t)(now - last_ecu_activity_ms) < 65u) {
        red=19; blue=25; // Purple ECU activity overlay.
    } else if (rpm <= 400u) {
        if ((now / 250u) & 1u) { red=26; green=15; } // Yellow cranking.
    } else {
        green=24; // Green running.
    }
    uint32_t grb=((uint32_t)green<<16)|((uint32_t)red<<8)|blue;
    if (grb != last_led_value && !pio_sm_is_tx_fifo_full(pio0, STATUS_LED_SM)) {
        pio_sm_put(pio0, STATUS_LED_SM, grb<<8);
        last_led_value=grb;
    }
}


typedef struct { uint64_t tick; uint8_t ch; uint8_t active; uint32_t duration_us;
    uint16_t angle; int16_t relative; uint8_t valid; uint32_t epoch; } event_t;
static event_t events[EVENT_QUEUE];
static uint32_t eq_head = 0, eq_tail = 0;
static char command[96];
static uint32_t command_len = 0;

// Phase marker is generated by the SAME PIO instruction stream as crank and cams,
// and is sampled by the SAME capture PIO/DMA stream as the ECU outputs.
// Consequently angle is not affected by core-to-core/USB scheduling latency.
// ANGLE reference = first tooth slot after missing gap, in a 720-degree cycle.
// Estimated period until two marker edges have been observed; afterwards measured.
static uint16_t angle_at(uint64_t tick, bool *valid) {
    *valid=false;
    if (!have_phase || !phase_rpm || tick < last_marker) return 0;
    uint64_t elapsed=tick-last_marker;
    uint64_t period=marker_period_samples ? marker_period_samples :
                    ((uint64_t)SAMPLE_HZ*120u/phase_rpm);
    if (!period || elapsed >= period) return 0; // never mislabel stale phase
    *valid=true;
    return (uint16_t)((elapsed*720u + period/2u)/period % 720u);
}
static int16_t relative_angle(uint16_t phase, uint8_t ch) {
    uint8_t cylinder=(ch%6u)+1u;
    uint8_t order_index=0;
    for (uint8_t i=0;i<ENGINE_CYLINDERS;i++)
        if (engine_firing_order[i]==cylinder) {order_index=i;break;}
    int32_t delta=((int32_t)phase - (int32_t)cyl1_tdc_deg - 120*(int32_t)order_index + 1080)%720;
    if (delta >= 360) delta-=720;
    return (int16_t)delta;
}
static void queue_event(uint64_t sample, uint8_t ch, bool on, uint32_t duration) {
    if (!stream) return;
    uint32_t next = (eq_head + 1u) % EVENT_QUEUE;
    if (next == eq_tail) { event_drops++; return; }
    bool valid;
    uint16_t angle=angle_at(sample,&valid);
    events[eq_head] = (event_t){.tick=sample, .ch=ch, .active=on,
        .duration_us=duration, .angle=angle, .relative=relative_angle(angle,ch),
        .valid=valid, .epoch=phase_epoch};
    eq_head = next;
}

// DMA streams a complete 720-degree waveform into two synchronized PIO state
// machines. PIO0 SM0 clocks the DAC over SPI-compatible pins and toggles LDAC;
// PIO0 SM1 updates both cams and the 720-degree reference with equal cycle count.
// No CPU per-sample SPI transactions or software-paced edges.
static void waveform_core(void) {
    wave_init();
    uint32_t running=0, seen_version=UINT32_MAX;
    while(true) {
        uint32_t want=requested_rpm, ver=shape_version;
        if(want!=running || ver!=seen_version) {
            wave_stop();
            __dmb();
            engine_shape_t local_shape=shape;
            seen_version=ver;
            running=want;
            if(running) wave_start(running,&local_shape);
            rpm=running;
        }
        tight_loop_contents();
    }
}

static void set_rpm(uint32_t value) {
    if (value != 0 && (value < MIN_RPM || value > MAX_RPM)) {
        printf("ERR RPM_RANGE %u..%u or 0\n", MIN_RPM, MAX_RPM);
        return;
    }
    requested_rpm=value;
    // Marker capture will synchronize phase at the first output-cycle boundary.
}

static uint64_t produced_samples(void) {
    // RP2040 DMA transfer_count reads remaining transfers, starting at UINT32_MAX.
    return (uint64_t)(UINT32_MAX - dma_hw->ch[dma_ch].transfer_count);
}

static void process_samples(void) {
    if (observed_shape_version != shape_version) {
        observed_shape_version = shape_version;
        have_phase = false;
        marker_period_samples = 0;
        previous_marker = false;
    }
    uint64_t produced = produced_samples();
    if (produced < sample_read) return;
    if (produced - sample_read >= RING_SAMPLES) {
        uint64_t lost = produced - sample_read - (RING_SAMPLES - 1);
        drop_samples += lost;
        sample_read += lost;
        previous_valid = false;
        previous_marker = false;
        have_phase=false; marker_period_samples=0;
    }
    // Leave a few transfers behind DMA writer, avoiding the slot currently being updated.
    uint64_t limit = produced > 2 ? produced - 2 : 0;
    while (sample_read < limit) {
        uint32_t raw = sample_ring[sample_read & RING_MASK] & 0x1ffffu;
        uint16_t now=0;
        for (uint c=0;c<6;c++) {
            now |= (uint16_t)(((raw>>(c == 5u ? 16u : 11u-c))&1u)<<c); // INJ1..5 GP21..17; INJ6 GP26
            now |= (uint16_t)(((raw>>c)&1u)<<(6u+c));          // COIL1..6 GP10..15
        }
        uint64_t tick = sample_read;
        ++sample_read;
        if (!previous_valid) {
            previous = now;
            previous_marker=(raw & (1u<<12))!=0;
            for (uint c=0; c<CHANNELS; ++c) {
                active[c] = ((now >> c) & 1u) != ((polarity_mask >> c) & 1u);
                start_sample[c] = tick;
            }
            previous_valid = true;
            continue;
        }
        // Marker GP22 is bit 12 in GP10..GP22 capture data.
        // previous marker is tracked separately from logical channel state.
        bool marker=(raw & (1u<<12))!=0;
        if (marker && !previous_marker) {
            if (have_phase && phase_rpm == rpm && tick > last_marker) {
                uint64_t span=tick-last_marker;
                // Reject unexpected short periods following an RPM restart.
                if (span >= 100 && span <= UINT32_MAX)
                    marker_period_samples=(uint32_t)span;
            }
            if (!have_phase || phase_rpm != rpm) marker_period_samples=0;
            last_marker=tick;
            waveform_cycle++;
            have_phase=true;
            phase_rpm=rpm;
            phase_epoch++;
        }
        previous_marker=marker;
        uint16_t changed = (previous ^ now) & 0x0fffu;
        previous = now;
        while (changed) {
            uint c = (uint)__builtin_ctz((unsigned)changed);
            last_ecu_activity_ms = to_ms_since_boot(get_absolute_time());
            changed &= changed - 1u;
            bool is_active = ((now >> c) & 1u) != ((polarity_mask >> c) & 1u);
            if (is_active) {
                start_sample[c] = tick;
                active[c] = true;
                rising_count[c]++;
                queue_event(tick, (uint8_t)c, true, 0);
            } else {
                uint32_t width = active[c] ? (uint32_t)((tick - start_sample[c]) * (1000000u / SAMPLE_HZ)) : 0;
                active[c] = false;
                pulse_us[c] = width;
                falling_count[c]++;
                queue_event(tick, (uint8_t)c, false, width);
            }
        }
        // Bounded processing keeps serial commands responsive during high capture load.
        if ((sample_read & 4095u) == 0u) break;
    }
}

static void report(void) {
    printf("STAT,%u,%llu,%llu,%llu", rpm,
           (unsigned long long)sample_read,
           (unsigned long long)drop_samples,
           (unsigned long long)event_drops);
    for (uint c=0; c<CHANNELS; ++c) {
        printf(",%lu,%lu,%lu", (unsigned long)rising_count[c],
               (unsigned long)falling_count[c], (unsigned long)pulse_us[c]);
    }
    putchar('\n');
}

static void send_events(void) {
    uint count=0;
    while (eq_tail != eq_head && count < 16) {
        event_t e=events[eq_tail];
        eq_tail=(eq_tail+1u)%EVENT_QUEUE;
        // Timestamp in microseconds since capture began (nominal 8us resolution).
        printf("ANG,%llu,%c,%u,%s,%lu,%d,%d,%u,%lu\n",
               (unsigned long long)(e.tick * (1000000u/SAMPLE_HZ)),
               e.ch < 6 ? 'I':'S', 1+(e.ch%6), e.active ? "ON":"OFF",
               (unsigned long)e.duration_us,
               e.valid ? (int)e.angle : -1,
               e.valid ? (int)e.relative : -999,
               (unsigned)e.valid, (unsigned long)e.epoch);
        ++count;
    }
}

static void handle_command(char *s) {
    while (*s && isspace((unsigned char)*s)) ++s;
    if (!strncmp(s,"RPM ",4)) {
        char *end;
        unsigned long n=strtoul(s+4,&end,10);
        if (end==s+4 || (*end && !isspace((unsigned char)*end)) || n > MAX_RPM) {
            puts("ERR BAD_RPM"); return;
        }
        set_rpm((uint32_t)n);
        printf("OK RPM %lu\n", (unsigned long)requested_rpm);
    } else if (!strncmp(s,"STREAM ",7)) {
        stream = (s[7]=='1');
        eq_tail=eq_head;
        printf("OK STREAM %u\n", stream ? 1u:0u);
    } else if (!strncmp(s,"POL ",4)) {
        char *end;
        unsigned long mask=strtoul(s+4,&end,0);
        if (end==s+4 || mask>0xfffu) { puts("ERR BAD_POL"); return; }
        polarity_mask=(uint16_t)mask;
        previous_valid=false;
        printf("OK POL 0x%03lx\n",mask);
    } else if (!strncmp(s,"WHEEL ",6)) {
        // WHEEL <nominal_slots_per_rev> <missing_slots> <invert:0|1>
        unsigned total,missing,invert;
        char extra;
        if (sscanf(s+6,"%u %u %u %c",&total,&missing,&invert,&extra)!=3 || invert>1 ||
            total>UINT16_MAX || missing>UINT16_MAX) {
            puts("ERR WHEEL_FORMAT WHEEL <total> <missing> <0|1>"); return;
        }
        crank_shape_t next={.teeth=(uint16_t)total,.missing=(uint16_t)missing,.invert=(bool)invert};
        if (!crank_shape_valid(&next)) {
            puts("ERR WHEEL_RANGE total=12..120 missing=1..16 missing<total"); return;
        }
        shape.crank=next;
        __dmb();
        shape_version++;
        printf("OK WHEEL %u %u %u RESET_PHASE\n",total,missing,invert);
    } else if (!strcmp(s,"WHEEL?")) {
        printf("WHEEL,%u,%u,%u\n",shape.crank.teeth,shape.crank.missing,shape.crank.invert);
    } else if (!strncmp(s,"CAM ",4)) {
        // CAM <G40|G163> <start_deg> <width_deg> <invert:0|1>
        char which[12]; int start,width,invert;
        if (sscanf(s+4,"%11s %d %d %d",which,&start,&width,&invert)!=4 ||
            width<0 || width>720 || (invert!=0 && invert!=1) ||
            (strcmp(which,"G40") && strcmp(which,"G163"))) {
            puts("ERR CAM_FORMAT CAM G40|G163 <angle> <width> <0|1>"); return;
        }
        engine_shape_t next=shape;
        cam_shape_t *c=(!strcmp(which,"G40"))? &next.g40 : &next.g163;
        c->start_deg=normalize_720(start);
        c->width_deg=(uint16_t)width;
        c->invert=(bool)invert;
        shape=next;
        __dmb();
        shape_version++;
        printf("OK CAM %s %u %u %d RESET_PHASE\n",which,
               normalize_720(start),(unsigned)width,invert);
    } else if (!strncmp(s,"TDC ",4)) {
        char *end; long v=strtol(s+4,&end,10);
        if (end==s+4 || (*end && !isspace((unsigned char)*end)) || v < -720 || v > 720) {
            puts("ERR TDC_RANGE -720..720"); return;
        }
        cyl1_tdc_deg=(int16_t)normalize_720((int32_t)v);
        printf("OK TDC %d (provisional relative-to-marker reference)\n",cyl1_tdc_deg);
    } else if (!strcmp(s,"TDC?")) {
        printf("TDC,%d,%s\n",cyl1_tdc_deg,ENGINE_NAME);
    } else if (!strcmp(s,"CAM?")) {
        printf("CAMS,%s,%d,%u,%u,%d,%u,%u,%lu\n",ENGINE_NAME,
          shape.g40.start_deg,shape.g40.width_deg,shape.g40.invert,
          shape.g163.start_deg,shape.g163.width_deg,shape.g163.invert,
          (unsigned long)waveform_cycle);
    } else if (!strcmp(s,"STAT")) report();
    else if (!strcmp(s,"HELP")) puts("CMDS: RPM <0|100..12000>, WHEEL <12..120> <1..16 missing> <invert 0|1>, WHEEL?, STREAM <0|1>, POL <0..4095>, CAM G40|G163 <start> <width> <invert>, CAM?, TDC <deg>, TDC?, STAT, HELP");
    else puts("ERR UNKNOWN_COMMAND");
}

static void serial_poll(void) {
    int ch;
    for (int n=0; n<64 && (ch=getchar_timeout_us(0)) != PICO_ERROR_TIMEOUT; ++n) {
        if (ch == '\r' || ch == '\n') {
            if (command_len) { command[command_len]=0; handle_command(command); command_len=0; }
        } else if (command_len < sizeof(command)-1) command[command_len++]=(char)ch;
    }
}

int main(void) {
    stdio_init_all();
    status_led_init();
    multicore_launch_core1(waveform_core);
    uint cap_off=pio_add_program(cap_pio, &capture17_program);
    capture17_program_init(cap_pio, cap_sm, cap_off, MON_GPIO);
    pio_sm_set_clkdiv(cap_pio, cap_sm, (float)clock_get_hz(clk_sys) / (2.0f*SAMPLE_HZ));
    dma_ch=dma_claim_unused_channel(true);
    dma_channel_config dc=dma_channel_get_default_config(dma_ch);
    channel_config_set_transfer_data_size(&dc, DMA_SIZE_32);
    channel_config_set_read_increment(&dc, false);
    channel_config_set_write_increment(&dc, true);
    channel_config_set_ring(&dc, true, RING_BITS); // RP2040 supports at most 32768-byte rings
    channel_config_set_dreq(&dc, pio_get_dreq(cap_pio, cap_sm, false));
    dma_channel_configure(dma_ch, &dc, sample_ring, &cap_pio->rxf[cap_sm], UINT32_MAX, true);
    pio_sm_set_enabled(cap_pio, cap_sm, true);
    absolute_time_t last_report=get_absolute_time();
    puts("BOOT ME71 DMA PIO MCP4922 G40=GP2 G163=GP3 CS5 SCK6 MOSI7 LDAC4 INJ1..5=GP21..17 INJ6=GP26 COIL10..15 REF22 LED16");
    while (true) {
        process_samples();
        serial_poll();
        status_led_update();
        // Only one event every loop, to prioritize keeping up with DMA.
        if (stream && eq_tail!=eq_head) send_events();
        if (absolute_time_diff_us(last_report, get_absolute_time()) >= REPORT_MS*1000) {
            report();
            last_report=get_absolute_time();
        }
        tight_loop_contents();
    }
}
